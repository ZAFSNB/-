#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QImage>
#include <QPushButton>
#include <QLabel>
#include <QComboBox>

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void onLoadButtonClicked();
    void onProcessButtonClicked();

private:
    // 图像处理函数
    void sharpenImage(QImage &image);  // 锐化
    void equalizeHistogram(QImage &image);  // 直方图均衡化
    void linearContrast(QImage &image);  // 线性对比度
    void otsuThreshold(QImage &image);  // Otsu阈值
    void adaptiveThreshold(QImage &image);  // 自适应阈值
    void morphologicalProcessing(QImage &image, const QString &element);  // 形态学处理

    // UI控件
    QPushButton *loadButton;
    QPushButton *processButton;
    QLabel *originalImageLabel;
    QLabel *processedImageLabel;
    QComboBox *methodComboBox;

    // 存储原始图像
    QImage originalImage;
};

#endif // MAINWINDOW_H
