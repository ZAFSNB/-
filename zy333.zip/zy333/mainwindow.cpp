#include "mainwindow.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QFileDialog>
#include <QMessageBox>
#include <QPixmap>
#include <QImageReader>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent),
    loadButton(new QPushButton("Load Image", this)),
    processButton(new QPushButton("Apply Processing", this)),
    originalImageLabel(new QLabel(this)),
    processedImageLabel(new QLabel(this)),
    methodComboBox(new QComboBox(this)),
    originalImage()
{
    // 创建中央部件和布局
    QWidget *centralWidget = new QWidget(this);
    QVBoxLayout *mainLayout = new QVBoxLayout(centralWidget);
    QHBoxLayout *imageLayout = new QHBoxLayout();

    // 配置方法选择下拉框
    methodComboBox->addItem("Sharpen");
    methodComboBox->addItem("Equalize Histogram");
    methodComboBox->addItem("Linear Contrast");
    methodComboBox->addItem("Otsu Threshold");
    methodComboBox->addItem("Adaptive Threshold");
    methodComboBox->addItem("Morphological Processing");

    // 配置按钮和标签
    originalImageLabel->setAlignment(Qt::AlignCenter);
    processedImageLabel->setAlignment(Qt::AlignCenter);

    // 将标签添加到水平布局中
    imageLayout->addWidget(originalImageLabel);
    imageLayout->addWidget(processedImageLabel);

    mainLayout->addWidget(loadButton);
    mainLayout->addWidget(processButton);
    mainLayout->addWidget(methodComboBox);
    mainLayout->addLayout(imageLayout);

    // 设置中央部件和布局
    setCentralWidget(centralWidget);

    // 连接按钮的点击事件
    connect(loadButton, &QPushButton::clicked, this, &MainWindow::onLoadButtonClicked);
    connect(processButton, &QPushButton::clicked, this, &MainWindow::onProcessButtonClicked);
}

MainWindow::~MainWindow()
{
    // 资源管理（如果有需要的话）
}

void MainWindow::onLoadButtonClicked()
{
    // 打开文件对话框，选择图像
    QString fileName = QFileDialog::getOpenFileName(this, "Open Image", "", "Images (*.png *.xpm *.jpg *.bmp)");
    if (fileName.isEmpty()) {
        return;
    }

    // 加载并显示图像
    if (originalImage.load(fileName)) {
        QPixmap pixmap = QPixmap::fromImage(originalImage);
        originalImageLabel->setPixmap(pixmap.scaled(originalImageLabel->size(), Qt::KeepAspectRatio));
        processedImageLabel->clear();  // 清除处理后的图像标签
    } else {
        QMessageBox::warning(this, "Error", "Failed to load the image.");
    }
}

void MainWindow::onProcessButtonClicked()
{
    if (originalImage.isNull()) {
        QMessageBox::warning(this, "Error", "Please load an image first.");
        return;
    }

    // 处理图像
    QImage processedImage = originalImage;
    QString method = methodComboBox->currentText();

    if (method == "Sharpen") {
        sharpenImage(processedImage);
    } else if (method == "Equalize Histogram") {
        equalizeHistogram(processedImage);
    } else if (method == "Linear Contrast") {
        linearContrast(processedImage);
    } else if (method == "Otsu Threshold") {
        otsuThreshold(processedImage);
    } else if (method == "Adaptive Threshold") {
        adaptiveThreshold(processedImage);
    } else if (method == "Morphological Processing") {
        morphologicalProcessing(processedImage, "square");
    }

    // 显示处理后的图像
    QPixmap originalPixmap = QPixmap::fromImage(originalImage);
    QPixmap processedPixmap = QPixmap::fromImage(processedImage);
    originalImageLabel->setPixmap(originalPixmap.scaled(originalImageLabel->size(), Qt::KeepAspectRatio));
    processedImageLabel->setPixmap(processedPixmap.scaled(processedImageLabel->size(), Qt::KeepAspectRatio));
}

void MainWindow::sharpenImage(QImage &image)
{
    int width = image.width();
    int height = image.height();
    QImage tempImage = image.copy();

    // 锐化内核（简单的拉普拉斯锐化内核）
    int kernel[3][3] = {
        {0, -1, 0},
        {-1, 5, -1},
        {0, -1, 0}
    };

    // 卷积操作
    for (int i = 1; i < width - 1; i++) {
        for (int j = 1; j < height - 1; j++) {
            int newPixel = 0;
            for (int dx = -1; dx <= 1; dx++) {
                for (int dy = -1; dy <= 1; dy++) {
                    int pixel = qGray(image.pixel(i + dx, j + dy));
                    newPixel += pixel * kernel[dx + 1][dy + 1];
                }
            }

            // 限制像素值范围在[0, 255]
            newPixel = std::min(std::max(newPixel, 0), 255);
            tempImage.setPixel(i, j, qRgb(newPixel, newPixel, newPixel));
        }
    }

    image = tempImage;  // 更新图像
}

void MainWindow::equalizeHistogram(QImage &image)
{
    int width = image.width();
    int height = image.height();
    int hist[256] = {0};

    // 计算图像的灰度直方图
    for (int i = 0; i < width; i++) {
        for (int j = 0; j < height; j++) {
            int pixel = qGray(image.pixel(i, j));
            hist[pixel]++;
        }
    }

    // 计算累计分布函数
    int totalPixels = width * height;
    int cumHist[256] = {0};
    cumHist[0] = hist[0];
    for (int i = 1; i < 256; i++) {
        cumHist[i] = cumHist[i - 1] + hist[i];
    }

    // 应用直方图均衡化
    for (int i = 0; i < width; i++) {
        for (int j = 0; j < height; j++) {
            int pixel = qGray(image.pixel(i, j));
            int newPixel = (cumHist[pixel] * 255) / totalPixels;
            image.setPixel(i, j, qRgb(newPixel, newPixel, newPixel));
        }
    }
}

void MainWindow::linearContrast(QImage &image)
{
    int width = image.width();
    int height = image.height();
    int minimum = 255, maximum = 0;

    // 找到最小和最大像素值
    for (int i = 0; i < width; i++) {
        for (int j = 0; j < height; j++) {
            int pixel = qGray(image.pixel(i, j));
            if (pixel < minimum) minimum = pixel;
            if (pixel > maximum) maximum = pixel;
        }
    }

    // 应用线性对比度增强
    for (int i = 0; i < width; i++) {
        for (int j = 0; j < height; j++) {
            int pixel = qGray(image.pixel(i, j));
            int newPixel = (pixel - minimum) * 255 / (maximum - minimum); // 线性拉伸
            image.setPixel(i, j, qRgb(newPixel, newPixel, newPixel));
        }
    }
}

void MainWindow::otsuThreshold(QImage &image)
{
    int width = image.width();
    int height = image.height();
    int hist[256] = {0};

    // 构建图像的灰度直方图
    for (int i = 0; i < width; i++) {
        for (int j = 0; j < height; j++) {
            int pixel = qGray(image.pixel(i, j));
            hist[pixel]++;
        }
    }

    int total = width * height;
    float sumB = 0, sum1 = 0, wB = 0, wF = 0;
    float maxVar = 0, threshold = 0;

    // 计算总和
    for (int i = 0; i < 256; i++) {
        sum1 += i * hist[i];
    }

    // 计算最佳阈值
    for (int i = 0; i < 256; i++) {
        wB += hist[i];
        if (wB == 0) continue;
        wF = total - wB;
        if (wF == 0) break;

        sumB += i * hist[i];
        float mB = sumB / wB;
        float mF = (sum1 - sumB) / wF;
        float betweenVar = wB * wF * (mB - mF) * (mB - mF);

        if (betweenVar > maxVar) {
            maxVar = betweenVar;
            threshold = i;
        }
    }

    // 应用阈值
    for (int i = 0; i < width; i++) {
        for (int j = 0; j < height; j++) {
            int pixel = qGray(image.pixel(i, j));
            int newPixel = (pixel > threshold) ? 255 : 0;
            image.setPixel(i, j, qRgb(newPixel, newPixel, newPixel));
        }
    }
}

void MainWindow::adaptiveThreshold(QImage &image)
{
    int width = image.width();
    int height = image.height();
    int windowSize = 15; // 常用的窗口大小
    int C = 10; // 调整常数

    QImage tempImage = image.copy();

    for (int i = 0; i < width; i++) {
        for (int j = 0; j < height; j++) {
            int localSum = 0;
            int count = 0;

            // 计算窗口内的局部均值
            for (int dx = -windowSize / 2; dx <= windowSize / 2; dx++) {
                for (int dy = -windowSize / 2; dy <= windowSize / 2; dy++) {
                    int nx = i + dx;
                    int ny = j + dy;

                    if (nx >= 0 && ny >= 0 && nx < width && ny < height) {
                        localSum += qGray(image.pixel(nx, ny));
                        count++;
                    }
                }
            }

            int localMean = localSum / count;
            int pixel = qGray(image.pixel(i, j));

            // 比较像素和局部平均值并应用阈值
            int newPixel = pixel > localMean - C ? 255 : 0;
            tempImage.setPixel(i, j, qRgb(newPixel, newPixel, newPixel));
        }
    }

    image = tempImage;
}

void MainWindow::morphologicalProcessing(QImage &image, const QString &element)
{
    int width = image.width();
    int height = image.height();
    QImage tempImage = image.copy();

    QSize structElementSize(3, 3);

    for (int i = 1; i < width - 1; i++) {
        for (int j = 1; j < height - 1; j++) {
            bool setWhite = false;

            for (int dx = -1; dx <= 1; dx++) {
                for (int dy = -1; dy <= 1; dy++) {
                    int nx = i + dx;
                    int ny = j + dy;

                    if (nx >= 0 && ny >= 0 && nx < width && ny < height) {
                        if (qGray(image.pixel(nx, ny)) == 255) {
                            setWhite = true;
                        }
                    }
                }
            }

            // 应用形态学操作（例如膨胀操作）
            if (setWhite) {
                tempImage.setPixel(i, j, qRgb(255, 255, 255));
            } else {
                tempImage.setPixel(i, j, qRgb(0, 0, 0));
            }
        }
    }

    image = tempImage;  // 应用处理结果
}
