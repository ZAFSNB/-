#include <QApplication>
#include <QWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QPushButton>
#include <QTableWidget>
#include <QFileDialog>
#include <QImageReader>
#include <QDebug>
#include <QHeaderView>
#include <QFileInfo>
#include <QImage>

class ImageInfoApp : public QWidget {
    Q_OBJECT

public:
    ImageInfoApp(QWidget *parent = nullptr);

private slots:
    void browseFiles();
    void displayImageInfo(const QStringList &filePaths);

private:
    QTableWidget *tableWidget;
};

ImageInfoApp::ImageInfoApp(QWidget *parent)
    : QWidget(parent) {

    QVBoxLayout *mainLayout = new QVBoxLayout(this);
    QHBoxLayout *buttonLayout = new QHBoxLayout();

    QPushButton *browseButton = new QPushButton("Browse", this);
    buttonLayout->addWidget(browseButton);

    connect(browseButton, &QPushButton::clicked, this, &ImageInfoApp::browseFiles);

    mainLayout->addLayout(buttonLayout);

    tableWidget = new QTableWidget(this);
    tableWidget->setColumnCount(5);
    QStringList headers = {"File Name", "Size (pixels)", "Resolution (dpi)", "Color Depth (bit)", "Format"};
    tableWidget->setHorizontalHeaderLabels(headers);
    tableWidget->horizontalHeader()->setStretchLastSection(true);

    mainLayout->addWidget(tableWidget);
    setLayout(mainLayout);
}

void ImageInfoApp::browseFiles() {
    QStringList filePaths = QFileDialog::getOpenFileNames(this, "Select Image Files", "",
                                                          "Images (*.jpg *.jpeg *.gif *.tif *.tiff *.bmp *.png *.psd)");

    if (!filePaths.isEmpty()) {
        displayImageInfo(filePaths);
    }
}

void ImageInfoApp::displayImageInfo(const QStringList &filePaths) {
    int currentRowCount = tableWidget->rowCount();
    tableWidget->setRowCount(currentRowCount + filePaths.size());

    for (int i = 0; i < filePaths.size(); ++i) {
        QString filePath = filePaths.at(i);
        QFileInfo fileInfo(filePath);
        QImageReader reader(filePath);

        if (!reader.canRead()) {
            qWarning() << "Can't read image: " << filePath;
            continue;
        }

        QImage image(filePath);

        QString fileName = fileInfo.fileName();
        QSize imageSize = reader.size();
        int width = imageSize.width();
        int height = imageSize.height();
        int resolutionX = image.physicalDpiX(); // Pixel per inch on X axis
        int resolutionY = image.physicalDpiY(); // Pixel per inch on Y axis
        int depth = image.depth();
        QString format = reader.format();

        int row = currentRowCount + i;
        tableWidget->setItem(row, 0, new QTableWidgetItem(fileName));
        tableWidget->setItem(row, 1, new QTableWidgetItem(QString("%1 x %2").arg(width).arg(height)));
        tableWidget->setItem(row, 2, new QTableWidgetItem(QString("%1 / %2").arg(resolutionX).arg(resolutionY)));
        tableWidget->setItem(row, 3, new QTableWidgetItem(QString::number(depth)));
        tableWidget->setItem(row, 4, new QTableWidgetItem(format));
    }
}

int main(int argc, char *argv[]) {
    QApplication app(argc, argv);

    ImageInfoApp window;
    window.resize(800, 600);
    window.setWindowTitle("Image Info Display");
    window.show();

    return app.exec();
}

#include "main.moc"
