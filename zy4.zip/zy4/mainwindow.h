#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QImage>
#include <QPushButton>
#include <QComboBox>
#include <QSpinBox>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QPainter>
#include <QElapsedTimer>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

protected:
    void paintEvent(QPaintEvent *event) override;

private slots:
    void on_drawButton_clicked();

private:
    Ui::MainWindow *ui;
    QImage *image;
    QPushButton *drawButton;
    QComboBox *algorithmComboBox;
    QSpinBox *x1SpinBox, *y1SpinBox, *x2SpinBox, *y2SpinBox, *radiusSpinBox;

    void initUI();
    void drawLineStepByStep(int x1, int y1, int x2, int y2);
    void drawLineDDA(int x1, int y1, int x2, int y2);
    void drawLineBresenham(int x1, int y1, int x2, int y2);
    void drawCircleBresenham(int xc, int yc, int radius);
};
#endif // MAINWINDOW_H
