#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <cmath>
#include <QDebug>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // 初始化透明背景图像
    image = new QImage(600, 400, QImage::Format_ARGB32);
    image->fill(Qt::transparent);

    // 初始化UI
    initUI();
}

MainWindow::~MainWindow()
{
    delete ui;
    delete image;
}

void MainWindow::initUI()
{
    // 创建UI组件
    drawButton = new QPushButton("Draw", this);
    algorithmComboBox = new QComboBox(this);
    x1SpinBox = new QSpinBox(this);
    y1SpinBox = new QSpinBox(this);
    x2SpinBox = new QSpinBox(this);
    y2SpinBox = new QSpinBox(this);
    radiusSpinBox = new QSpinBox(this);

    // 设置数值范围和宽度
    x1SpinBox->setRange(-9999, 9999);
    y1SpinBox->setRange(-9999, 9999);
    x2SpinBox->setRange(-9999, 9999);
    y2SpinBox->setRange(-9999, 9999);
    radiusSpinBox->setRange(0, 9999);

    x1SpinBox->setFixedWidth(80);
    y1SpinBox->setFixedWidth(80);
    x2SpinBox->setFixedWidth(80);
    y2SpinBox->setFixedWidth(80);
    radiusSpinBox->setFixedWidth(80);

    // 添加算法选项
    algorithmComboBox->addItems({"Step-by-Step Line", "DDA Line", "Bresenham Line", "Bresenham Circle"});

    // 布局设置
    QVBoxLayout *inputLayout = new QVBoxLayout;
    inputLayout->addWidget(new QLabel("Algorithm:", this));
    inputLayout->addWidget(algorithmComboBox);
    inputLayout->addWidget(new QLabel("x1:", this));
    inputLayout->addWidget(x1SpinBox);
    inputLayout->addWidget(new QLabel("y1:", this));
    inputLayout->addWidget(y1SpinBox);
    inputLayout->addWidget(new QLabel("x2:", this));
    inputLayout->addWidget(x2SpinBox);
    inputLayout->addWidget(new QLabel("y2:", this));
    inputLayout->addWidget(y2SpinBox);
    inputLayout->addWidget(new QLabel("Radius:", this));
    inputLayout->addWidget(radiusSpinBox);
    inputLayout->addWidget(drawButton);

    // 设置主布局，将输入区域放置在绘图区域左侧
    QHBoxLayout *mainLayout = new QHBoxLayout;
    mainLayout->addLayout(inputLayout);

    QLabel *drawingArea = new QLabel(this);
    drawingArea->setFixedSize(600, 400); // 确保绘图区域大小固定
    mainLayout->addWidget(drawingArea);

    QWidget *centralWidget = new QWidget(this);
    centralWidget->setLayout(mainLayout);
    setCentralWidget(centralWidget);

    // 连接绘图按钮
    connect(drawButton, &QPushButton::clicked, this, &MainWindow::on_drawButton_clicked);
}

void MainWindow::paintEvent(QPaintEvent *event)
{
    QPainter painter(this);

    // 绘制网格
    painter.setPen(QPen(Qt::lightGray, 1, Qt::DotLine));
    int step = 20;
    for (int x = step; x < width(); x += step) {
        painter.drawLine(x, 0, x, height());
    }
    for (int y = step; y < height(); y += step) {
        painter.drawLine(0, y, width(), y);
    }

    // 绘制坐标轴
    painter.setPen(QPen(Qt::black, 2));
    painter.drawLine(width() / 2, 0, width() / 2, height());
    painter.drawLine(0, height() / 2, width(), height() / 2);

    // 将图像叠加在网格和坐标轴上
    int xOffset = width() / 2 - image->width() / 2;
    int yOffset = height() / 2 - image->height() / 2;
    painter.drawImage(xOffset, yOffset, *image);
}

void MainWindow::on_drawButton_clicked()
{
    image->fill(Qt::transparent); // 清除图像

    int x1 = x1SpinBox->value();
    int y1 = y1SpinBox->value();
    int x2 = x2SpinBox->value();
    int y2 = y2SpinBox->value();
    int radius = radiusSpinBox->value();

    int algorithm = algorithmComboBox->currentIndex();
    QElapsedTimer timer;
    timer.start();

    switch (algorithm) {
    case 0: drawLineStepByStep(x1 + 300, 200 - y1, x2 + 300, 200 - y2); break;
    case 1: drawLineDDA(x1 + 300, 200 - y1, x2 + 300, 200 - y2); break;
    case 2: drawLineBresenham(x1 + 300, 200 - y1, x2 + 300, 200 - y2); break;
    case 3: drawCircleBresenham(x1 + 300, 200 - y1, radius); break;
    }

    qDebug() << "Algorithm execution time:" << timer.elapsed() << "milliseconds";
    update();
}

void MainWindow::drawLineStepByStep(int x1, int y1, int x2, int y2)
{
    QPainter painter(image);
    painter.setPen(Qt::black);

    int dx = x2 - x1;
    int dy = y2 - y1;
    int steps = std::max(abs(dx), abs(dy));

    float xIncrement = dx / float(steps);
    float yIncrement = dy / float(steps);

    float x = x1;
    float y = y1;

    for (int i = 0; i <= steps; i++) {
        painter.drawPoint(round(x), round(y));
        x += xIncrement;
        y += yIncrement;
    }
}

void MainWindow::drawLineDDA(int x1, int y1, int x2, int y2)
{
    QPainter painter(image);
    painter.setPen(Qt::black);

    int dx = x2 - x1;
    int dy = y2 - y1;
    int steps = std::max(abs(dx), abs(dy));

    float xIncrement = dx / float(steps);
    float yIncrement = dy / float(steps);

    float x = x1;
    float y = y1;

    for (int i = 0; i <= steps; i++) {
        painter.drawPoint(round(x), round(y));
        x += xIncrement;
        y += yIncrement;
    }
}

void MainWindow::drawLineBresenham(int x1, int y1, int x2, int y2)
{
    QPainter painter(image);
    painter.setPen(Qt::black);

    int dx = std::abs(x2 - x1), dy = std::abs(y2 - y1);
    int sx = x1 < x2 ? 1 : -1;
    int sy = y1 < y2 ? 1 : -1;
    int err = dx - dy;

    while (true) {
        painter.drawPoint(x1, y1);
        if (x1 == x2 && y1 == y2) break;
        int e2 = 2 * err;
        if (e2 > -dy) {
            err -= dy;
            x1 += sx;
        }
        if (e2 < dx) {
            err += dx;
            y1 += sy;
        }
    }
}

void MainWindow::drawCircleBresenham(int xc, int yc, int radius)
{
    QPainter painter(image);
    painter.setPen(Qt::black);

    int x = 0;
    int y = radius;
    int d = 3 - 2 * radius;

    while (y >= x) {
        painter.drawPoint(xc + x, yc + y);
        painter.drawPoint(xc - x, yc + y);
        painter.drawPoint(xc + x, yc - y);
        painter.drawPoint(xc - x, yc - y);
        painter.drawPoint(xc + y, yc + x);
        painter.drawPoint(xc - y, yc + x);
        painter.drawPoint(xc + y, yc - x);
        painter.drawPoint(xc - y, yc - x);

        x++;
        if (d > 0) {
            y--;
            d = d + 4 * (x - y) + 10;
        } else {
            d = d + 4 * x + 6;
        }
    }
}

